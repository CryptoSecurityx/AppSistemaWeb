import time, pyodbc,re
import socket

import sistema
from sistema import ConexaoServidor
from paginas import Gerenciamento_Pagina
# NEED INSTALL unixodbc-dev or unixodbc <-

from flask import Flask, request, render_template, redirect
from datetime import datetime

app = Flask(__name__, static_url_path='/static', static_folder='static')
app.config['DEBUG'] = True


def ConexaoServidorFunc():
    Homepage = open('templates/home.html', 'r').read()
    portas = [38121, 38125, 38101]
    IP = "192.168.15.30"
    RetornoHome = ""

    Conexao = ConexaoServidor(IP, portas, Homepage, RetornoHome)

    for cadaporta in Conexao.portas:  # testa porta por porta da portlist
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.settimeout(0.1)
        connect = client.connect_ex((Conexao.server, cadaporta))

    if connect == 0:
        PortasAbertas = portas

        Conexao.RetornoHome = Conexao.LerpaginaHome.replace(
            '<font size="6" color="lime"> ...</font> | LoginServer Status:<font size="6" color="red"> ...',
            '<font color="lime"> Online</font> LoginServer Status:<font color="lime"> Online')
        print(f"--> Servidor Ligado: {PortasAbertas}")
        return Conexao.RetornoHome

    else:
        print(f"--> Servidor Fechado : {portas}")
        return render_template('/home.html')

    # Aplicacao = Servidor("localhost", "80" "Online", "Online")
    # Aplicacao.desativar()


@app.route("/")
def home():
    Manutencao()
    return Gerenciamento_Pagina(ConexaoServidorFunc())


@app.route("/criaracesso")
def registerpage():
    return render_template("access.html")


@app.route("/criaracesso", methods=['POST'])
def AnalisarResponse():
    #try:
    usuario = request.form['username']
    email = request.form['email']
    password = request.form['password']
    confirmpass = request.form['password_confirmation']
    hashtoken = request.form['_token']
    # dtnascimento = datetime.strptime(request.form['data'], "%Y-%m-%d")
    print(len(usuario), len(password))


    if (len(password)<8):
        return SenhaRegra()
    elif not re.search("[a-z]", password):
        return SenhaRegra()
    elif not re.search("[A-Z]", password):
        return SenhaRegra()
    elif not re.search("[0-9]", password):
        return SenhaRegra()
    elif not re.search("[_@$]", password):
        return SenhaRegra()
    elif re.search("\s", password):
        return SenhaRegra()


    SegurancaReforcada = [
        '&', 'AND', '#', ';','(', ')', '/', "'", '"', '``', 'http', ',', '&', '`', ';', '=', 'echo', 'tee', '=',
        '==', 'or', 'order by', 'from',"tee","cat"]

    for fuzz in range(len( SegurancaReforcada)):
        usuario = usuario.strip(str(fuzz))
        password = password.strip(str(fuzz))



    #time.sleep(4)

    #password.strip()
    #email.strip()

    print(f"Dados de Entrada: {usuario},{password},{email}")

    if (usuario =="")or  (email=="")or (password=="") or (confirmpass=="") or (usuario == SegurancaReforcada) or (password == SegurancaReforcada) or (email== SegurancaReforcada) :
        return PreencherCampos()


    else:

        if request.method == 'POST' and password == confirmpass:
            ########## String de Conexao ###########

            server = '192.168.15.30\CABALSERVER,1433'
            database = 'account'
            username = 'sa'
            passwordb = 'Adminz1ak90a0'
            conexao = pyodbc.connect(
                'DRIVER={ODBC Driver 17 for SQL Server};SERVER=' + server + ';DATABASE=' + database + ';UID=' + username + ';PWD=' + passwordb)
            command = conexao.cursor()

            print("Consultando:", usuario)
            # select ID from dbo.cabal_auth_table WHERE ID = 'teste';
            RESPOSTASQL = command.execute(
                f"select ID from dbo.cabal_auth_table WHERE ID = '{usuario}';").rowcount
            print('---> Resposta do SQL: ' + str(RESPOSTASQL))

            #data = command.fetchall()

            #for row in data:
            #    print(row[1])
            if RESPOSTASQL == 0:
                #CadastrarBancoSucesso(usuario, email, password, hashtoken)

                print(f'--> New User {usuario} Cadastrado')
                return Pagsucesso()
            else:
                return UsuarioExiste(usuario)
                print("usuario ja existe")



    #except:
    #    return Manutencao()


        #
        #except:
        #


def Manutencao():
    pagina = open('templates/access.html', 'r').read()

    pagina = pagina.replace('<p class="mb-0">     <a href="" class="text-success">',
    '<p class="mb-0"><font color="red"> Alerta: Sistema em Manutencao. </font><a href="" class="text-success">')

    return Gerenciamento_Pagina.Pagina_Manutencao(pagina)



    # resposta.find('<p class="mb-0">    ######################### <a href="" class="text-success">')



def UsuarioExiste(usuario):
    pagina = open('templates/access.html', 'r').read()
    # resposta.find('<p class="mb-0">    ######################### <a href="" class="text-success">')
    pagina = pagina.replace('<p class="mb-0">     <a href="" class="text-success">',
                            f'<p class="mb-0"><font color="yellow">  Usuario: {usuario} ja Existe.  </font><a href="" class="text-success">')

    return pagina

    # print("O USUARIO NAO EXISTE")
    # CadastrarBancoSucesso(usuario, email, password, hashtoken)

    # UsuarioExiste(usuario, RESPOSTASQL)

    # print(ConsultaSQLResposta(Consulta))
    # RESPOSTASQL

    # try:

    # except:
    #    return PreencherCampos()

def SenhaRegra():
    pagina = open('templates/access.html', 'r').read()
    # resposta.find('<p class="mb-0">    ######################### <a href="" class="text-success">')
    pagina = pagina.replace('<p class="mb-0">     <a href="" class="text-success">',
                            f'<p class="mb-0"><font color="red">  A Senha deve ter Pelo menos 7 caracteres.  </font><a href="" class="text-success">')

    return pagina

def EmailExiste(email):
    pagina = open('templates/access.html', 'r').read()
    # resposta.find('<p class="mb-0">    ######################### <a href="" class="text-success">')
    pagina = pagina.replace('<p class="mb-0">     <a href="" class="text-success">',
                            f'<p class="mb-0"><font color="yellow">  Usuario: {email} ja Existe.  </font><a href="" class="text-success">')

    return pagina




def Pagsucesso():
    return render_template('/Sucesss.html')


def CadastrarBancoSucesso(usuario, email, password, hashtoken):
    ########## String de Conexao ###########

    server = '192.168.15.30\CABALSERVER,1433'
    database = 'account'
    username = 'sa'
    passwordb = 'Adminz1ak90a0'
    conexao = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};SERVER=' + server + ';DATABASE=' + database + ';UID=' + username + ';PWD=' + passwordb)
    command = conexao.cursor()
    count = command.execute(
        f"exec dbo.cabal_tool_registerAccount '{usuario}','{password}','{email}','{hashtoken}','{hashtoken}';").rowcount

    # INSERT INTO dbo.cabal_auth_table (ID,Password,Email,Chave,Hash) VALUES ('{usuario}','{password}','{email}','{hashtoken}','{hashtoken}')").rowcount

    command.commit()


    print('Resposta do Servidor: ' + str(count))

    # TESTE
    # command.execute('SELECT @@version;')
    # row = command.fetchone()
    # while row:
    #    print(row[0])
    #    row = command.fetchone()
    # time.sleep(5)


def PreencherCampos():
    pagina = open('templates/access.html', 'r').read()
    # resposta.find('<p class="mb-0">    ######################### <a href="" class="text-success">')
    pagina = pagina.replace('<p class="mb-0">     <a href="" class="text-success">',
                            '<p class="mb-0"><font color="yellow">  Por-favor, Preencha Corretamente os dados a cima.  </font><a href="" class="text-success">')
    return pagina


@app.errorhandler(404)
def page_not_found(e):
    return render_template("/404.html")


@app.route("/login")
def login():
    paginaerro = open('templates/404.html', 'r').read()
    responseerro = paginaerro.replace('404', '')
    responseerro = responseerro.replace('Oops Caiu no Limbo  <br> Nada FOI Encontrado.',
                                        '<center><img src="/static/img/cabalsnlogo.jpg"> </img> <br><br> Pagina inicial em Desenvolvimento.</center>')

    return render_template("/home.html")


app.run(host='127.0.0.1', port=443)