class Gerenciamento_Pagina:

    def __init__(self,home):
        self.home = home


    def Pagina_Manutencao(self, pagina):

        self.pagina = pagina




