
class ConexaoServidor:

    def __init__(self,server,portas,LerpaginaHome,RetornoHome):
        self.server = server
        self.portas = portas
        self.LerpaginaHome = LerpaginaHome
        self.RetornoHome = RetornoHome








